# Simple runner for the maze demonstration

from maze_comparison import main

if __name__ == "__main__":
    # Run the full demonstration
    main()
